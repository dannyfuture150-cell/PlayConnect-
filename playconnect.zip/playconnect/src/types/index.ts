import { Timestamp } from "firebase/firestore";

export type GamingPlatform = "PC" | "PlayStation" | "Xbox" | "Mobile" | "Switch";

export type SkillLevel = "Rookie" | "Amateur" | "Pro" | "Elite" | "Legend";

/** users/{uid} */
export interface UserProfile {
  uid: string;
  username: string; // unique, lowercase, used in URLs
  displayName: string;
  email: string;
  bio: string;
  country: string; // ISO country code
  photoURL: string | null;
  bannerURL: string | null;
  favoriteGames: string[];
  platform: GamingPlatform | null;
  skillLevel: SkillLevel;
  efootballId?: string;
  eaFcId?: string;
  discordUsername?: string;
  twitchUrl?: string;
  youtubeUrl?: string;
  tiktokUrl?: string;
  followersCount: number;
  followingCount: number;
  postsCount: number;
  reputationScore: number;
  badges: string[]; // badge ids, resolved against badges/{id}
  onboardingComplete: boolean;
  isAdmin?: boolean;
  isBanned?: boolean;
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

/** posts/{postId} */
export interface Post {
  id: string;
  authorId: string;
  author: PostAuthorSnapshot;
  text: string;
  mediaUrls: string[];
  mediaType: "none" | "image" | "video" | "clip";
  gameTag?: string;
  likesCount: number;
  commentsCount: number;
  sharesCount: number;
  savesCount: number;
  createdAt: Timestamp;
}

/** Denormalized author info stored on the post for fast feed rendering */
export interface PostAuthorSnapshot {
  uid: string;
  username: string;
  displayName: string;
  photoURL: string | null;
}

/** posts/{postId}/comments/{commentId} */
export interface Comment {
  id: string;
  postId: string;
  authorId: string;
  author: PostAuthorSnapshot;
  text: string;
  createdAt: Timestamp;
}

/** posts/{postId}/likes/{uid} and other like subcollections use this shape */
export interface Like {
  uid: string;
  createdAt: Timestamp;
}

/** followers/{uid}/list/{followerId} */
export interface FollowEdge {
  uid: string;
  createdAt: Timestamp;
}

/** stories/{storyId} */
export interface Story {
  id: string;
  authorId: string;
  author: PostAuthorSnapshot;
  mediaUrl: string;
  mediaType: "image" | "video";
  viewers: string[];
  createdAt: Timestamp;
  expiresAt: Timestamp;
}

/** notifications/{uid}/items/{notificationId} */
export interface AppNotification {
  id: string;
  type: "like" | "comment" | "follow" | "message" | "tournament_invite" | "community_invite";
  fromUid: string;
  fromUser: PostAuthorSnapshot;
  postId?: string;
  communityId?: string;
  tournamentId?: string;
  read: boolean;
  createdAt: Timestamp;
}

/** communities/{communityId} */
export interface Community {
  id: string;
  name: string;
  slug: string;
  game: string;
  description: string;
  bannerURL: string | null;
  rules: string[];
  moderatorIds: string[];
  memberCount: number;
  createdBy: string;
  createdAt: Timestamp;
}

/** tournaments/{tournamentId} */
export interface Tournament {
  id: string;
  title: string;
  game: string;
  description: string;
  organizerId: string;
  communityId?: string;
  format: "single_elimination" | "double_elimination" | "round_robin";
  maxParticipants: number;
  participantIds: string[];
  status: "upcoming" | "live" | "completed";
  startsAt: Timestamp;
  createdAt: Timestamp;
}

/** reports/{reportId} */
export interface Report {
  id: string;
  reporterId: string;
  targetType: "post" | "comment" | "user" | "community";
  targetId: string;
  reason: string;
  status: "open" | "reviewed" | "dismissed";
  createdAt: Timestamp;
}

/** badges/{badgeId} */
export interface Badge {
  id: string;
  name: string;
  description: string;
  iconUrl: string;
}
