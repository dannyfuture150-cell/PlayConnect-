"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import * as Tabs from "@radix-ui/react-tabs";
import { sendPasswordResetEmail } from "firebase/auth";
import { auth } from "@/lib/firebase/client";
import { useAuth } from "@/providers/AuthProvider";
import { useAuthActions } from "@/hooks/useAuthActions";
import { EditProfileForm } from "@/components/profile/EditProfileForm";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export default function SettingsPage() {
  const { profile, user } = useAuth();
  const { signOut } = useAuthActions();
  const router = useRouter();
  const [resetSent, setResetSent] = useState(false);

  async function handleSignOut() {
    await signOut();
    router.push("/login");
  }

  async function handleResetPassword() {
    if (!user?.email) return;
    await sendPasswordResetEmail(auth, user.email);
    setResetSent(true);
  }

  return (
    <div className="flex flex-col gap-6">
      <h1 className="font-display text-2xl font-bold text-slate-900">Settings</h1>

      <Tabs.Root defaultValue="profile">
        <Tabs.List className="flex gap-1 rounded-xl border border-slate-200 bg-slate-50 p-1">
          {["profile", "account"].map((tab) => (
            <Tabs.Trigger
              key={tab}
              value={tab}
              className={cn(
                "flex-1 rounded-lg px-4 py-2 text-sm font-medium capitalize text-steel/60 transition-colors",
                "data-[state=active]:bg-slate-200 data-[state=active]:text-slate-900"
              )}
            >
              {tab}
            </Tabs.Trigger>
          ))}
        </Tabs.List>

        <Tabs.Content value="profile" className="mt-6">
          <Card className="p-6">
            <EditProfileForm />
          </Card>
        </Tabs.Content>

        <Tabs.Content value="account" className="mt-6">
          <Card className="flex flex-col gap-5 p-6">
            <div>
              <h3 className="font-display text-base font-semibold text-slate-900">Email</h3>
              <p className="mt-1 text-sm text-steel/50">{user?.email}</p>
            </div>

            <div className="border-t border-slate-100 pt-5">
              <h3 className="font-display text-base font-semibold text-slate-900">Password</h3>
              <p className="mt-1 text-sm text-steel/50">Send a reset link to your inbox.</p>
              <Button variant="outline" className="mt-3" onClick={handleResetPassword} disabled={resetSent}>
                {resetSent ? "Reset link sent" : "Send reset link"}
              </Button>
            </div>

            <div className="border-t border-slate-100 pt-5">
              <h3 className="font-display text-base font-semibold text-slate-900">Sign out</h3>
              <p className="mt-1 text-sm text-steel/50">End your session on this device.</p>
              <Button variant="outline" className="mt-3" onClick={handleSignOut}>
                Sign out
              </Button>
            </div>

            <div className="border-t border-slate-100 pt-5">
              <h3 className="font-display text-base font-semibold text-signal-red">Delete account</h3>
              <p className="mt-1 text-sm text-steel/50">
                Permanently removes your profile, posts, and data. This cannot be undone.
              </p>
              <Button variant="destructive" className="mt-3">
                Delete account
              </Button>
            </div>
          </Card>
        </Tabs.Content>
      </Tabs.Root>
    </div>
  );
}
