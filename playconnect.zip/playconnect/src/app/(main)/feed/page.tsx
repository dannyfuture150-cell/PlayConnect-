import { CreatePostForm } from "@/components/feed/CreatePostForm";
import { FeedList } from "@/components/feed/FeedList";

export default function FeedPage() {
  return (
    <div className="flex flex-col gap-5">
      <CreatePostForm />
      <FeedList />
    </div>
  );
}
