import { AuthGuard } from "@/components/shared/AuthGuard";
import { Navbar } from "@/components/layout/Navbar";
import { Sidebar } from "@/components/layout/Sidebar";

export default function MainLayout({ children }: { children: React.ReactNode }) {
  return (
    <AuthGuard>
      <div className="min-h-screen bg-void">
        <Navbar />
        <div className="flex">
          <Sidebar />
          <main className="min-h-[calc(100vh-4rem)] flex-1 px-4 py-6 md:px-8">
            <div className="mx-auto w-full max-w-3xl">{children}</div>
          </main>
        </div>
      </div>
    </AuthGuard>
  );
}
