"use client";

import { useQuery } from "@tanstack/react-query";
import { collection, getDocs, limit, orderBy, query, where } from "firebase/firestore";
import { db } from "@/lib/firebase/client";
import type { Post, UserProfile } from "@/types";

export function useProfileByUsername(username: string) {
  return useQuery<UserProfile | null>({
    queryKey: ["profile", username],
    queryFn: async () => {
      const q = query(collection(db, "users"), where("username", "==", username), limit(1));
      const snap = await getDocs(q);
      if (snap.empty) return null;
      return snap.docs[0].data() as UserProfile;
    },
    enabled: !!username,
  });
}

export function useUserPosts(uid: string | undefined) {
  return useQuery<Post[]>({
    queryKey: ["userPosts", uid],
    queryFn: async () => {
      const q = query(
        collection(db, "posts"),
        where("authorId", "==", uid),
        orderBy("createdAt", "desc"),
        limit(20)
      );
      const snap = await getDocs(q);
      return snap.docs.map((d) => ({ id: d.id, ...d.data() } as Post));
    },
    enabled: !!uid,
  });
}
