"use client";

import { useState } from "react";
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signInWithPopup,
  sendPasswordResetEmail,
  signOut as firebaseSignOut,
  updateProfile,
} from "firebase/auth";
import { doc, serverTimestamp, setDoc } from "firebase/firestore";
import { auth, db, googleProvider } from "@/lib/firebase/client";

/** Maps Firebase Auth error codes to friendly, actionable copy. */
function friendlyAuthError(code: string): string {
  switch (code) {
    case "auth/email-already-in-use":
      return "An account with this email already exists. Try logging in instead.";
    case "auth/invalid-email":
      return "That email address looks invalid.";
    case "auth/weak-password":
      return "Choose a stronger password.";
    case "auth/user-not-found":
    case "auth/wrong-password":
    case "auth/invalid-credential":
      return "Incorrect email or password.";
    case "auth/too-many-requests":
      return "Too many attempts. Wait a moment and try again.";
    case "auth/popup-closed-by-user":
      return "Google sign-in was closed before finishing.";
    default:
      return "Something went wrong. Please try again.";
  }
}

/** Creates the initial users/{uid} document for a brand-new account. */
async function createUserDocIfMissing(uid: string, email: string, displayName: string, photoURL: string | null) {
  await setDoc(
    doc(db, "users", uid),
    {
      uid,
      email,
      displayName,
      username: "",
      bio: "",
      country: "",
      photoURL,
      bannerURL: null,
      favoriteGames: [],
      platform: null,
      skillLevel: "Rookie",
      followersCount: 0,
      followingCount: 0,
      postsCount: 0,
      reputationScore: 0,
      badges: [],
      onboardingComplete: false,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    },
    { merge: true }
  );
}

export function useAuthActions() {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function signUpWithEmail(email: string, password: string) {
    setIsLoading(true);
    setError(null);
    try {
      const cred = await createUserWithEmailAndPassword(auth, email, password);
      await createUserDocIfMissing(cred.user.uid, email, email.split("@")[0], null);
      return cred.user;
    } catch (err: any) {
      setError(friendlyAuthError(err?.code ?? ""));
      throw err;
    } finally {
      setIsLoading(false);
    }
  }

  async function loginWithEmail(email: string, password: string) {
    setIsLoading(true);
    setError(null);
    try {
      const cred = await signInWithEmailAndPassword(auth, email, password);
      return cred.user;
    } catch (err: any) {
      setError(friendlyAuthError(err?.code ?? ""));
      throw err;
    } finally {
      setIsLoading(false);
    }
  }

  async function loginWithGoogle() {
    setIsLoading(true);
    setError(null);
    try {
      const cred = await signInWithPopup(auth, googleProvider);
      await createUserDocIfMissing(
        cred.user.uid,
        cred.user.email ?? "",
        cred.user.displayName ?? "Player",
        cred.user.photoURL
      );
      return cred.user;
    } catch (err: any) {
      setError(friendlyAuthError(err?.code ?? ""));
      throw err;
    } finally {
      setIsLoading(false);
    }
  }

  async function resetPassword(email: string) {
    setIsLoading(true);
    setError(null);
    try {
      await sendPasswordResetEmail(auth, email);
    } catch (err: any) {
      setError(friendlyAuthError(err?.code ?? ""));
      throw err;
    } finally {
      setIsLoading(false);
    }
  }

  async function signOut() {
    await firebaseSignOut(auth);
  }

  return {
    signUpWithEmail,
    loginWithEmail,
    loginWithGoogle,
    resetPassword,
    signOut,
    isLoading,
    error,
  };
}
