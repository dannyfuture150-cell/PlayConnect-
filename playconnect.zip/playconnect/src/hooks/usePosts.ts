"use client";

import { useInfiniteQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  addDoc,
  collection,
  deleteDoc,
  doc,
  DocumentSnapshot,
  getDocs,
  increment,
  limit,
  onSnapshot,
  orderBy,
  query,
  QueryDocumentSnapshot,
  serverTimestamp,
  setDoc,
  startAfter,
  updateDoc,
} from "firebase/firestore";
import { db } from "@/lib/firebase/client";
import type { Post, PostAuthorSnapshot } from "@/types";

const PAGE_SIZE = 10;

interface FeedPage {
  posts: Post[];
  cursor: QueryDocumentSnapshot | null;
}

/** Infinite-scrolling feed, newest posts first. */
export function useFeed() {
  return useInfiniteQuery<FeedPage>({
    queryKey: ["feed"],
    initialPageParam: null as QueryDocumentSnapshot | null,
    queryFn: async ({ pageParam }) => {
      const base = query(
        collection(db, "posts"),
        orderBy("createdAt", "desc"),
        ...(pageParam ? [startAfter(pageParam as DocumentSnapshot)] : []),
        limit(PAGE_SIZE)
      );
      const snap = await getDocs(base);
      return {
        posts: snap.docs.map((d) => ({ id: d.id, ...d.data() } as Post)),
        cursor: snap.docs.length ? snap.docs[snap.docs.length - 1] : null,
      };
    },
    getNextPageParam: (lastPage) => (lastPage.posts.length === PAGE_SIZE ? lastPage.cursor : undefined),
  });
}

export function useCreatePost() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (input: { text: string; author: PostAuthorSnapshot; mediaUrls?: string[]; gameTag?: string }) => {
      await addDoc(collection(db, "posts"), {
        authorId: input.author.uid,
        author: input.author,
        text: input.text,
        mediaUrls: input.mediaUrls ?? [],
        mediaType: input.mediaUrls?.length ? "image" : "none",
        gameTag: input.gameTag ?? null,
        likesCount: 0,
        commentsCount: 0,
        sharesCount: 0,
        savesCount: 0,
        createdAt: serverTimestamp(),
      });
      await updateDoc(doc(db, "users", input.author.uid), {
        postsCount: increment(1),
      });
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["feed"] }),
  });
}

export function useToggleLike(postId: string, uid: string) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (currentlyLiked: boolean) => {
      const likeRef = doc(db, "posts", postId, "likes", uid);
      const postRef = doc(db, "posts", postId);
      if (currentlyLiked) {
        await deleteDoc(likeRef);
        await updateDoc(postRef, { likesCount: increment(-1) });
      } else {
        await setDoc(likeRef, { uid, createdAt: serverTimestamp() });
        await updateDoc(postRef, { likesCount: increment(1) });
      }
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["feed"] }),
  });
}

export function useAddComment(postId: string) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (input: { text: string; author: PostAuthorSnapshot }) => {
      await addDoc(collection(db, "posts", postId, "comments"), {
        postId,
        authorId: input.author.uid,
        author: input.author,
        text: input.text,
        createdAt: serverTimestamp(),
      });
      await updateDoc(doc(db, "posts", postId), { commentsCount: increment(1) });
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["feed"] }),
  });
}

/** Live-subscribes to whether the given user has liked a post (for the like button state). */
export function subscribeToLikeStatus(postId: string, uid: string, cb: (liked: boolean) => void) {
  return onSnapshot(doc(db, "posts", postId, "likes", uid), (snap) => cb(snap.exists()));
}
