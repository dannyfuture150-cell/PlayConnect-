// Curated for brevity — swap for a full ISO-3166 list or a package like
// `i18n-iso-countries` when wiring up production data.
export const COUNTRIES = [
  "United States", "United Kingdom", "Canada", "Australia", "Germany",
  "France", "Spain", "Italy", "Netherlands", "Sweden", "Norway", "Poland",
  "Brazil", "Argentina", "Mexico", "Japan", "South Korea", "China", "India",
  "Indonesia", "Philippines", "Vietnam", "Thailand", "Malaysia", "Singapore",
  "Nigeria", "Egypt", "South Africa", "Kenya", "Morocco", "Saudi Arabia",
  "United Arab Emirates", "Turkey", "Pakistan", "Bangladesh",
].sort();
