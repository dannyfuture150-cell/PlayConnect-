"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { formatDistanceToNow } from "date-fns";
import { Heart, MessageCircle, Share2, Bookmark } from "lucide-react";
import type { Post } from "@/types";
import { useToggleLike, subscribeToLikeStatus } from "@/hooks/usePosts";
import { useAuth } from "@/providers/AuthProvider";
import { formatCount, cn } from "@/lib/utils";
import { Card } from "@/components/ui/card";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { CommentSection } from "@/components/feed/CommentSection";

export function PostCard({ post }: { post: Post }) {
  const { profile } = useAuth();
  const [liked, setLiked] = useState(false);
  const [showComments, setShowComments] = useState(false);
  const toggleLike = useToggleLike(post.id, profile?.uid ?? "");

  useEffect(() => {
    if (!profile) return;
    return subscribeToLikeStatus(post.id, profile.uid, setLiked);
  }, [post.id, profile]);

  return (
    <Card className="overflow-hidden">
      <div className="flex items-center gap-3 p-4 pb-3">
        <Link href={`/profile/${post.author.username}`}>
          <Avatar>
            <AvatarImage src={post.author.photoURL ?? undefined} alt={post.author.displayName} />
            <AvatarFallback>{post.author.displayName[0]?.toUpperCase()}</AvatarFallback>
          </Avatar>
        </Link>
        <div className="flex-1">
          <Link href={`/profile/${post.author.username}`} className="text-sm font-semibold text-slate-900 hover:underline">
            {post.author.displayName}
          </Link>
          <p className="text-xs text-steel/40">
            @{post.author.username} ·{" "}
            {post.createdAt ? formatDistanceToNow(post.createdAt.toDate(), { addSuffix: true }) : "just now"}
          </p>
        </div>
        {post.gameTag && (
          <span className="rounded-full border border-violet/30 bg-violet/10 px-2.5 py-1 text-[11px] font-medium text-violet-glow">
            {post.gameTag}
          </span>
        )}
      </div>

      {post.text && <p className="whitespace-pre-wrap px-4 pb-3 text-sm leading-relaxed text-steel/90">{post.text}</p>}

      {post.mediaUrls?.length > 0 && (
        <div className="relative aspect-video w-full bg-slate-50">
          <Image src={post.mediaUrls[0]} alt="Post media" fill className="object-cover" />
        </div>
      )}

      <div className="flex items-center gap-1 border-t border-slate-100 px-2 py-1">
        <ActionButton
          icon={<Heart className={cn("h-4 w-4", liked && "fill-signal-red text-signal-red")} />}
          label={formatCount(post.likesCount)}
          active={liked}
          onClick={() => profile && toggleLike.mutate(liked)}
        />
        <ActionButton
          icon={<MessageCircle className="h-4 w-4" />}
          label={formatCount(post.commentsCount)}
          onClick={() => setShowComments((s) => !s)}
        />
        <ActionButton icon={<Share2 className="h-4 w-4" />} label={formatCount(post.sharesCount)} />
        <ActionButton icon={<Bookmark className="h-4 w-4" />} label={formatCount(post.savesCount)} className="ml-auto" />
      </div>

      {showComments && <CommentSection postId={post.id} />}
    </Card>
  );
}

function ActionButton({
  icon,
  label,
  onClick,
  active,
  className,
}: {
  icon: React.ReactNode;
  label: string;
  onClick?: () => void;
  active?: boolean;
  className?: string;
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "flex items-center gap-1.5 rounded-lg px-3 py-2 text-xs font-medium transition-colors",
        active ? "text-signal-red" : "text-steel/50 hover:bg-slate-100 hover:text-steel",
        className
      )}
    >
      {icon}
      {label}
    </button>
  );
}
