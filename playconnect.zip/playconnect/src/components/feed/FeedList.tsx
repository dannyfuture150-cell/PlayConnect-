"use client";

import { useEffect, useRef } from "react";
import { useFeed } from "@/hooks/usePosts";
import { PostCard } from "@/components/feed/PostCard";

export function FeedList() {
  const { data, fetchNextPage, hasNextPage, isFetchingNextPage, isLoading, isError } = useFeed();
  const sentinelRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!sentinelRef.current) return;
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && hasNextPage && !isFetchingNextPage) {
          fetchNextPage();
        }
      },
      { rootMargin: "300px" }
    );
    observer.observe(sentinelRef.current);
    return () => observer.disconnect();
  }, [hasNextPage, isFetchingNextPage, fetchNextPage]);

  if (isLoading) {
    return (
      <div className="flex flex-col gap-4">
        {[...Array(3)].map((_, i) => (
          <div key={i} className="h-40 animate-pulse rounded-2xl bg-slate-50" />
        ))}
      </div>
    );
  }

  if (isError) {
    return <p className="text-sm text-signal-red">Couldn&apos;t load the feed. Check your Firebase config and try again.</p>;
  }

  const posts = data?.pages.flatMap((p) => p.posts) ?? [];

  if (posts.length === 0) {
    return (
      <div className="rounded-2xl border border-slate-200 bg-slate-50 p-10 text-center">
        <p className="text-sm text-steel/50">No posts yet. Be the first to drop a play.</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-4">
      {posts.map((post) => (
        <PostCard key={post.id} post={post} />
      ))}
      <div ref={sentinelRef} className="h-8" />
      {isFetchingNextPage && <p className="text-center text-xs text-steel/40">Loading more…</p>}
    </div>
  );
}
