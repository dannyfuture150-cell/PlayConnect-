"use client";

import { useState } from "react";
import { formatDistanceToNow } from "date-fns";
import { useComments } from "@/hooks/useComments";
import { useAddComment } from "@/hooks/usePosts";
import { useAuth } from "@/providers/AuthProvider";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

export function CommentSection({ postId }: { postId: string }) {
  const { profile } = useAuth();
  const { comments, loading } = useComments(postId, true);
  const addComment = useAddComment(postId);
  const [text, setText] = useState("");

  async function submit() {
    if (!profile || !text.trim()) return;
    await addComment.mutateAsync({
      text: text.trim(),
      author: {
        uid: profile.uid,
        username: profile.username,
        displayName: profile.displayName,
        photoURL: profile.photoURL,
      },
    });
    setText("");
  }

  return (
    <div className="flex flex-col gap-3 border-t border-slate-100 px-4 py-3">
      {loading && <p className="text-xs text-steel/40">Loading comments…</p>}

      {comments.map((c) => (
        <div key={c.id} className="flex gap-2.5">
          <Avatar className="h-7 w-7">
            <AvatarImage src={c.author.photoURL ?? undefined} alt={c.author.displayName} />
            <AvatarFallback className="text-[11px]">{c.author.displayName[0]?.toUpperCase()}</AvatarFallback>
          </Avatar>
          <div className="flex-1 rounded-xl bg-slate-100 px-3 py-2">
            <div className="flex items-baseline gap-2">
              <span className="text-xs font-semibold text-slate-900">{c.author.displayName}</span>
              <span className="text-[11px] text-steel/40">
                {c.createdAt ? formatDistanceToNow(c.createdAt.toDate(), { addSuffix: true }) : "now"}
              </span>
            </div>
            <p className="text-sm text-steel/80">{c.text}</p>
          </div>
        </div>
      ))}

      {profile && (
        <div className="flex items-center gap-2 pt-1">
          <Avatar className="h-7 w-7">
            <AvatarImage src={profile.photoURL ?? undefined} alt={profile.displayName} />
            <AvatarFallback className="text-[11px]">{profile.displayName[0]?.toUpperCase()}</AvatarFallback>
          </Avatar>
          <Input
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && submit()}
            placeholder="Add a comment…"
            className="h-9"
          />
          <Button size="sm" onClick={submit} disabled={!text.trim() || addComment.isPending}>
            Send
          </Button>
        </div>
      )}
    </div>
  );
}
