"use client";

import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { ImagePlus, Send } from "lucide-react";
import { createPostSchema, type CreatePostInput } from "@/lib/validations/profile";
import { useCreatePost } from "@/hooks/usePosts";
import { useAuth } from "@/providers/AuthProvider";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Card } from "@/components/ui/card";

export function CreatePostForm() {
  const { profile } = useAuth();
  const createPost = useCreatePost();
  const {
    register,
    handleSubmit,
    reset,
    watch,
    formState: { errors },
  } = useForm<CreatePostInput>({ resolver: zodResolver(createPostSchema), defaultValues: { text: "" } });

  const text = watch("text");

  async function onSubmit(data: CreatePostInput) {
    if (!profile) return;
    await createPost.mutateAsync({
      text: data.text,
      gameTag: data.gameTag,
      author: {
        uid: profile.uid,
        username: profile.username,
        displayName: profile.displayName,
        photoURL: profile.photoURL,
      },
    });
    reset();
  }

  if (!profile) return null;

  return (
    <Card className="p-4">
      <form onSubmit={handleSubmit(onSubmit)} className="flex gap-3">
        <Avatar className="mt-0.5 h-10 w-10">
          <AvatarImage src={profile.photoURL ?? undefined} alt={profile.displayName} />
          <AvatarFallback>{profile.displayName[0]?.toUpperCase()}</AvatarFallback>
        </Avatar>

        <div className="flex-1">
          <Textarea
            placeholder={`What's the play, ${profile.displayName.split(" ")[0]}?`}
            className="min-h-[60px] border-transparent bg-transparent px-0 py-1.5 focus-visible:ring-0"
            {...register("text")}
          />
          {errors.text && <p className="text-xs text-signal-red">{errors.text.message}</p>}

          <div className="mt-2 flex items-center justify-between">
            <button
              type="button"
              className="flex items-center gap-1.5 rounded-lg px-2 py-1.5 text-xs font-medium text-steel/50 hover:bg-slate-100 hover:text-steel"
              title="Media upload wires into Firebase Storage — see docs/FIREBASE_SETUP.md"
            >
              <ImagePlus className="h-4 w-4" />
              Media
            </button>

            <Button type="submit" size="sm" disabled={!text?.trim() || createPost.isPending}>
              <Send className="h-3.5 w-3.5" />
              {createPost.isPending ? "Posting…" : "Post"}
            </Button>
          </div>
        </div>
      </form>
    </Card>
  );
}
