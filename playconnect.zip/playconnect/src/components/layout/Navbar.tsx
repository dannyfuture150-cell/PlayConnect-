"use client";

import { useRouter } from "next/navigation";
import { Search, LogOut } from "lucide-react";
import * as DropdownMenu from "@radix-ui/react-dropdown-menu";
import { Logo } from "@/components/shared/Logo";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/providers/AuthProvider";
import { useAuthActions } from "@/hooks/useAuthActions";

export function Navbar() {
  const { profile } = useAuth();
  const { signOut } = useAuthActions();
  const router = useRouter();

  async function handleSignOut() {
    await signOut();
    router.push("/login");
  }

  return (
    <header className="sticky top-0 z-30 flex h-16 items-center justify-between border-b border-slate-100 bg-void/80 px-4 backdrop-blur-md md:px-6">
      <Logo size={36} />

      <div className="hidden max-w-md flex-1 items-center gap-2 px-8 md:flex">
        <div className="relative w-full">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-steel/40" />
          <Input placeholder="Search players, games, communities…" className="pl-9" />
        </div>
      </div>

      <DropdownMenu.Root>
        <DropdownMenu.Trigger asChild>
          <button className="flex items-center gap-2 rounded-full transition-opacity hover:opacity-80">
            <Avatar className="h-9 w-9">
              <AvatarImage src={profile?.photoURL ?? undefined} alt={profile?.displayName ?? "Player"} />
              <AvatarFallback>{profile?.displayName?.[0]?.toUpperCase() ?? "P"}</AvatarFallback>
            </Avatar>
          </button>
        </DropdownMenu.Trigger>
        <DropdownMenu.Portal>
          <DropdownMenu.Content
            align="end"
            className="z-40 min-w-[180px] rounded-xl border border-slate-200 bg-void p-1.5 shadow-2xl"
          >
            <DropdownMenu.Item asChild>
              <a
                href={profile ? `/profile/${profile.username}` : "#"}
                className="block cursor-pointer rounded-lg px-3 py-2 text-sm text-steel/80 outline-none hover:bg-slate-100 hover:text-slate-900"
              >
                My profile
              </a>
            </DropdownMenu.Item>
            <DropdownMenu.Item asChild>
              <a
                href="/settings"
                className="block cursor-pointer rounded-lg px-3 py-2 text-sm text-steel/80 outline-none hover:bg-slate-100 hover:text-slate-900"
              >
                Settings
              </a>
            </DropdownMenu.Item>
            <DropdownMenu.Separator className="my-1 h-px bg-slate-100" />
            <DropdownMenu.Item
              onClick={handleSignOut}
              className="flex cursor-pointer items-center gap-2 rounded-lg px-3 py-2 text-sm text-signal-red outline-none hover:bg-signal-red/10"
            >
              <LogOut className="h-4 w-4" />
              Sign out
            </DropdownMenu.Item>
          </DropdownMenu.Content>
        </DropdownMenu.Portal>
      </DropdownMenu.Root>
    </header>
  );
}
