"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Home, Users, Trophy, Compass, Bell, MessageCircle, Settings, User } from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth } from "@/providers/AuthProvider";

const NAV_ITEMS = [
  { href: "/feed", label: "Feed", icon: Home },
  { href: "/explore", label: "Explore", icon: Compass },
  { href: "/communities", label: "Communities", icon: Users },
  { href: "/tournaments", label: "Tournaments", icon: Trophy },
  { href: "/messages", label: "Messages", icon: MessageCircle },
  { href: "/notifications", label: "Notifications", icon: Bell },
];

export function Sidebar() {
  const pathname = usePathname();
  const { profile } = useAuth();

  return (
    <aside className="hidden w-64 shrink-0 flex-col gap-1 border-r border-slate-100 px-3 py-6 md:flex">
      <nav className="flex flex-col gap-1">
        {NAV_ITEMS.map(({ href, label, icon: Icon }) => {
          const active = pathname?.startsWith(href);
          return (
            <Link
              key={href}
              href={href}
              className={cn(
                "flex items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm font-medium transition-colors",
                active ? "bg-slate-100 text-slate-900" : "text-steel/60 hover:bg-slate-100 hover:text-slate-900"
              )}
            >
              <Icon className={cn("h-[18px] w-[18px]", active && "text-violet-glow")} />
              {label}
            </Link>
          );
        })}
      </nav>

      <div className="mt-2 h-px bg-slate-50" />

      <div className="mt-2 flex flex-col gap-1">
        {profile && (
          <Link
            href={`/profile/${profile.username}`}
            className={cn(
              "flex items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm font-medium transition-colors",
              pathname?.startsWith("/profile") ? "bg-slate-100 text-slate-900" : "text-steel/60 hover:bg-slate-100 hover:text-slate-900"
            )}
          >
            <User className="h-[18px] w-[18px]" />
            My profile
          </Link>
        )}
        <Link
          href="/settings"
          className={cn(
            "flex items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm font-medium transition-colors",
            pathname?.startsWith("/settings") ? "bg-slate-100 text-slate-900" : "text-steel/60 hover:bg-slate-100 hover:text-slate-900"
          )}
        >
          <Settings className="h-[18px] w-[18px]" />
          Settings
        </Link>
      </div>
    </aside>
  );
}
