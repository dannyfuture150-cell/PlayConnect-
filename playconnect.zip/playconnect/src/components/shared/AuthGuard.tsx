"use client";

import { ReactNode, useEffect } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/providers/AuthProvider";
import { PageLoader } from "@/components/shared/PageLoader";

/**
 * Wrap any (main) route with this. Redirects to /login if signed out, and to
 * /onboarding if signed in but the profile hasn't been completed yet.
 */
export function AuthGuard({ children }: { children: ReactNode }) {
  const { user, profile, loading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (loading) return;
    if (!user) {
      router.replace("/login");
      return;
    }
    if (profile && !profile.onboardingComplete) {
      router.replace("/onboarding");
    }
  }, [user, profile, loading, router]);

  if (loading || !user || (profile && !profile.onboardingComplete)) {
    return <PageLoader />;
  }

  return <>{children}</>;
}
