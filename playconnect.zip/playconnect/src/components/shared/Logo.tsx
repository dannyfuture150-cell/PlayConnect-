import Image from "next/image";
import Link from "next/link";
import { cn } from "@/lib/utils";

interface LogoProps {
  size?: number;
  withWordmark?: boolean;
  className?: string;
}

/**
 * Renders the PlayConnect mark. The source file (public/logo.png) already
 * contains the wordmark and tagline, so `withWordmark` controls whether we
 * show the full lockup (landing/auth screens) or just the glyph-cropped
 * version at small sizes (navbar).
 */
export function Logo({ size = 40, withWordmark = false, className }: LogoProps) {
  return (
    <Link href="/" className={cn("flex items-center gap-2 select-none", className)}>
      <div
        className="relative shrink-0 overflow-hidden rounded-lg"
        style={{ width: size, height: size }}
      >
        <Image src="/logo.png" alt="PlayConnect" fill sizes={`${size}px`} className="object-cover object-top scale-[2.4] translate-y-[2%]" priority />
      </div>
      {withWordmark && (
        <span className="font-display text-xl font-bold tracking-tight">
          <span className="text-steel">PLAY</span>{" "}
          <span className="bg-brand-gradient bg-clip-text text-transparent">CONNECT</span>
        </span>
      )}
    </Link>
  );
}
