"use client";

import { useState } from "react";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { doc, serverTimestamp, updateDoc } from "firebase/firestore";
import { db } from "@/lib/firebase/client";
import { useAuth } from "@/providers/AuthProvider";
import { editProfileSchema, type EditProfileInput } from "@/lib/validations/profile";
import { COUNTRIES } from "@/lib/countries";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { ChipMultiSelect } from "@/components/shared/ChipMultiSelect";

const PLATFORMS = ["PC", "PlayStation", "Xbox", "Mobile", "Switch"] as const;

export function EditProfileForm() {
  const { profile } = useAuth();
  const [saved, setSaved] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);

  const {
    register,
    handleSubmit,
    control,
    formState: { errors, isSubmitting },
  } = useForm<EditProfileInput>({
    resolver: zodResolver(editProfileSchema),
    defaultValues: {
      displayName: profile?.displayName ?? "",
      bio: profile?.bio ?? "",
      country: profile?.country ?? "",
      platform: (profile?.platform as any) ?? "PC",
      favoriteGames: profile?.favoriteGames ?? [],
      efootballId: profile?.efootballId ?? "",
      eaFcId: profile?.eaFcId ?? "",
      discordUsername: profile?.discordUsername ?? "",
      twitchUrl: profile?.twitchUrl ?? "",
      youtubeUrl: profile?.youtubeUrl ?? "",
      tiktokUrl: profile?.tiktokUrl ?? "",
    },
  });

  async function onSubmit(data: EditProfileInput) {
    if (!profile) return;
    setSubmitError(null);
    try {
      await updateDoc(doc(db, "users", profile.uid), {
        ...data,
        updatedAt: serverTimestamp(),
      });
      setSaved(true);
      setTimeout(() => setSaved(false), 2500);
    } catch {
      setSubmitError("Couldn't save changes. Please try again.");
    }
  }

  if (!profile) return null;

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-5">
      <div className="flex flex-col gap-1.5">
        <Label htmlFor="displayName">Display name</Label>
        <Input id="displayName" {...register("displayName")} />
        {errors.displayName && <p className="text-xs text-signal-red">{errors.displayName.message}</p>}
      </div>

      <div className="flex flex-col gap-1.5">
        <Label htmlFor="bio">Bio</Label>
        <Textarea id="bio" {...register("bio")} />
        {errors.bio && <p className="text-xs text-signal-red">{errors.bio.message}</p>}
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="flex flex-col gap-1.5">
          <Label htmlFor="country">Country</Label>
          <select id="country" {...register("country")} className="h-11 rounded-xl border border-slate-200 bg-slate-100 px-3 text-sm text-slate-900">
            <option value="">Select…</option>
            {COUNTRIES.map((c) => <option key={c} value={c}>{c}</option>)}
          </select>
        </div>
        <div className="flex flex-col gap-1.5">
          <Label htmlFor="platform">Platform</Label>
          <select id="platform" {...register("platform")} className="h-11 rounded-xl border border-slate-200 bg-slate-100 px-3 text-sm text-slate-900">
            {PLATFORMS.map((p) => <option key={p} value={p}>{p}</option>)}
          </select>
        </div>
      </div>

      <div className="flex flex-col gap-1.5">
        <Label>Favorite games</Label>
        <Controller
          name="favoriteGames"
          control={control}
          render={({ field }) => <ChipMultiSelect value={field.value} onChange={field.onChange} />}
        />
        {errors.favoriteGames && <p className="text-xs text-signal-red">{errors.favoriteGames.message}</p>}
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="flex flex-col gap-1.5">
          <Label htmlFor="efootballId">eFootball ID</Label>
          <Input id="efootballId" {...register("efootballId")} />
        </div>
        <div className="flex flex-col gap-1.5">
          <Label htmlFor="eaFcId">EA FC ID</Label>
          <Input id="eaFcId" {...register("eaFcId")} />
        </div>
        <div className="flex flex-col gap-1.5">
          <Label htmlFor="discordUsername">Discord username</Label>
          <Input id="discordUsername" {...register("discordUsername")} />
        </div>
        <div className="flex flex-col gap-1.5">
          <Label htmlFor="twitchUrl">Twitch URL</Label>
          <Input id="twitchUrl" {...register("twitchUrl")} />
          {errors.twitchUrl && <p className="text-xs text-signal-red">{errors.twitchUrl.message}</p>}
        </div>
        <div className="flex flex-col gap-1.5">
          <Label htmlFor="youtubeUrl">YouTube URL</Label>
          <Input id="youtubeUrl" {...register("youtubeUrl")} />
          {errors.youtubeUrl && <p className="text-xs text-signal-red">{errors.youtubeUrl.message}</p>}
        </div>
        <div className="flex flex-col gap-1.5">
          <Label htmlFor="tiktokUrl">TikTok URL</Label>
          <Input id="tiktokUrl" {...register("tiktokUrl")} />
          {errors.tiktokUrl && <p className="text-xs text-signal-red">{errors.tiktokUrl.message}</p>}
        </div>
      </div>

      {submitError && <p className="text-sm text-signal-red">{submitError}</p>}
      {saved && <p className="text-sm text-signal-green">Profile saved.</p>}

      <Button type="submit" size="lg" className="self-start" disabled={isSubmitting}>
        {isSubmitting ? "Saving…" : "Save changes"}
      </Button>
    </form>
  );
}
