import { Trophy, Shield, Award } from "lucide-react";
import type { UserProfile } from "@/types";
import { formatCount } from "@/lib/utils";
import { Card } from "@/components/ui/card";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";

const SKILL_RANK_COLOR: Record<string, string> = {
  Rookie: "text-steel/70 border-steel/30 bg-steel/5",
  Amateur: "text-signal-blue border-signal-blue/30 bg-signal-blue/10",
  Pro: "text-cyan border-cyan/30 bg-cyan/10",
  Elite: "text-violet-glow border-violet/40 bg-violet/10",
  Legend: "text-signal-purple border-signal-purple/40 bg-signal-purple/10",
};

export function PlayerCard({ profile }: { profile: UserProfile }) {
  const skillColor = SKILL_RANK_COLOR[profile.skillLevel] ?? SKILL_RANK_COLOR.Rookie;

  return (
    <Card className="relative overflow-hidden p-6">
      <div className="pointer-events-none absolute inset-0 bg-brand-radial opacity-60" />

      <div className="relative flex items-center gap-4">
        <Avatar className="h-16 w-16">
          <AvatarImage src={profile.photoURL ?? undefined} alt={profile.displayName} />
          <AvatarFallback className="text-lg">{profile.displayName[0]?.toUpperCase()}</AvatarFallback>
        </Avatar>
        <div>
          <h3 className="font-display text-lg font-bold text-slate-900">{profile.displayName}</h3>
          <p className="text-sm text-steel/50">@{profile.username}</p>
          <p className="mt-0.5 text-xs text-steel/40">{profile.country || "Unknown region"}</p>
        </div>
        <span className={`ml-auto rounded-full border px-3 py-1 text-xs font-semibold ${skillColor}`}>
          {profile.skillLevel}
        </span>
      </div>

      <div className="relative mt-5 grid grid-cols-3 gap-3 text-center">
        <Stat label="Followers" value={formatCount(profile.followersCount)} />
        <Stat label="Reputation" value={formatCount(profile.reputationScore)} />
        <Stat label="Posts" value={formatCount(profile.postsCount)} />
      </div>

      <div className="relative mt-5 flex flex-wrap gap-1.5">
        {profile.favoriteGames.slice(0, 4).map((game) => (
          <span key={game} className="rounded-full border border-slate-200 bg-slate-100 px-2.5 py-1 text-[11px] text-steel/70">
            {game}
          </span>
        ))}
      </div>

      <div className="relative mt-5 flex items-center gap-4 border-t border-slate-100 pt-4 text-xs text-steel/50">
        <span className="flex items-center gap-1.5">
          <Trophy className="h-3.5 w-3.5 text-violet-glow" /> {profile.badges.length} badges
        </span>
        <span className="flex items-center gap-1.5">
          <Shield className="h-3.5 w-3.5 text-cyan" /> {profile.platform ?? "—"}
        </span>
        <span className="flex items-center gap-1.5">
          <Award className="h-3.5 w-3.5 text-signal-purple" /> Rank #—
        </span>
      </div>
    </Card>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl bg-slate-50 py-2.5">
      <p className="font-display text-lg font-bold text-slate-900">{value}</p>
      <p className="text-[10px] uppercase tracking-wide text-steel/40">{label}</p>
    </div>
  );
}
