"use client";

import Link from "next/link";
import Image from "next/image";
import { Twitch, Youtube, MessageSquare } from "lucide-react";
import type { UserProfile } from "@/types";
import { useAuth } from "@/providers/AuthProvider";
import { formatCount } from "@/lib/utils";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";

export function ProfileHeader({ profile }: { profile: UserProfile }) {
  const { profile: viewer } = useAuth();
  const isOwnProfile = viewer?.uid === profile.uid;

  return (
    <div className="overflow-hidden rounded-2xl border border-slate-200">
      <div className="relative h-40 w-full bg-brand-gradient sm:h-52">
        {profile.bannerURL && (
          <Image src={profile.bannerURL} alt="" fill className="object-cover" />
        )}
      </div>

      <div className="bg-slate-50 px-6 pb-6">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div className="-mt-10 flex items-end gap-4">
            <Avatar className="h-24 w-24 border-4 border-void">
              <AvatarImage src={profile.photoURL ?? undefined} alt={profile.displayName} />
              <AvatarFallback className="text-2xl">{profile.displayName[0]?.toUpperCase()}</AvatarFallback>
            </Avatar>
            <div className="pb-1">
              <h1 className="font-display text-xl font-bold text-slate-900">{profile.displayName}</h1>
              <p className="text-sm text-steel/50">@{profile.username}</p>
            </div>
          </div>

          {isOwnProfile ? (
            <Link href="/settings">
              <Button variant="outline">Edit profile</Button>
            </Link>
          ) : (
            <Button>Follow</Button>
          )}
        </div>

        {profile.bio && <p className="mt-4 max-w-2xl text-sm leading-relaxed text-steel/80">{profile.bio}</p>}

        <div className="mt-4 flex flex-wrap items-center gap-5 text-sm text-steel/60">
          <span><strong className="text-slate-900">{formatCount(profile.followersCount)}</strong> followers</span>
          <span><strong className="text-slate-900">{formatCount(profile.followingCount)}</strong> following</span>
          {profile.country && <span>{profile.country}</span>}
          {profile.platform && <span>{profile.platform}</span>}
        </div>

        <div className="mt-4 flex items-center gap-3">
          {profile.discordUsername && (
            <span className="flex items-center gap-1.5 rounded-full border border-slate-200 px-3 py-1 text-xs text-steel/60">
              <MessageSquare className="h-3.5 w-3.5" /> {profile.discordUsername}
            </span>
          )}
          {profile.twitchUrl && (
            <a href={profile.twitchUrl} target="_blank" rel="noreferrer" className="rounded-full border border-slate-200 p-2 text-steel/60 hover:text-slate-900">
              <Twitch className="h-4 w-4" />
            </a>
          )}
          {profile.youtubeUrl && (
            <a href={profile.youtubeUrl} target="_blank" rel="noreferrer" className="rounded-full border border-slate-200 p-2 text-steel/60 hover:text-slate-900">
              <Youtube className="h-4 w-4" />
            </a>
          )}
        </div>
      </div>
    </div>
  );
}
