"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { doc, getDoc, serverTimestamp, setDoc } from "firebase/firestore";
import { db } from "@/lib/firebase/client";
import { useAuth } from "@/providers/AuthProvider";
import { onboardingSchema, type OnboardingInput } from "@/lib/validations/auth";
import { slugifyUsername } from "@/lib/utils";
import { COUNTRIES } from "@/lib/countries";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { ChipMultiSelect } from "@/components/shared/ChipMultiSelect";

const PLATFORMS = ["PC", "PlayStation", "Xbox", "Mobile", "Switch"] as const;

export function OnboardingForm() {
  const router = useRouter();
  const { user, profile } = useAuth();
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [checkingUsername, setCheckingUsername] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const {
    register,
    handleSubmit,
    control,
    setValue,
    watch,
    formState: { errors },
  } = useForm<OnboardingInput>({
    resolver: zodResolver(onboardingSchema),
    defaultValues: {
      username: profile?.username || slugifyUsername(profile?.displayName || ""),
      displayName: profile?.displayName || "",
      country: "",
      platform: "PC",
      favoriteGames: [],
      bio: "",
    },
  });

  const favoriteGames = watch("favoriteGames");

  async function onSubmit(data: OnboardingInput) {
    if (!user) return;
    setSubmitError(null);
    setIsSubmitting(true);
    try {
      setCheckingUsername(true);
      const usernameRef = doc(db, "usernames", data.username);
      const usernameSnap = await getDoc(usernameRef);
      setCheckingUsername(false);

      if (usernameSnap.exists() && usernameSnap.data().uid !== user.uid) {
        setSubmitError("That username is already taken.");
        setIsSubmitting(false);
        return;
      }

      // Reserve the username in its own collection so lookups & uniqueness
      // checks don't require scanning the users collection.
      await setDoc(usernameRef, { uid: user.uid });

      await setDoc(
        doc(db, "users", user.uid),
        {
          username: data.username,
          displayName: data.displayName,
          country: data.country,
          platform: data.platform,
          favoriteGames: data.favoriteGames,
          bio: data.bio ?? "",
          onboardingComplete: true,
          updatedAt: serverTimestamp(),
        },
        { merge: true }
      );

      router.push("/feed");
    } catch (err) {
      setSubmitError("Something went wrong saving your profile. Please try again.");
      setIsSubmitting(false);
    }
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-5">
      <div className="flex flex-col gap-1.5">
        <Label htmlFor="username">Username</Label>
        <Input
          id="username"
          placeholder="e.g. shadow_striker"
          {...register("username")}
          onChange={(e) => setValue("username", slugifyUsername(e.target.value))}
        />
        {errors.username && <p className="text-xs text-signal-red">{errors.username.message}</p>}
      </div>

      <div className="flex flex-col gap-1.5">
        <Label htmlFor="displayName">Display name</Label>
        <Input id="displayName" placeholder="How you want to show up" {...register("displayName")} />
        {errors.displayName && <p className="text-xs text-signal-red">{errors.displayName.message}</p>}
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="flex flex-col gap-1.5">
          <Label htmlFor="country">Country</Label>
          <select
            id="country"
            {...register("country")}
            className="h-11 rounded-xl border border-slate-200 bg-slate-100 px-3 text-sm text-slate-900 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet/50"
          >
            <option value="">Select…</option>
            {COUNTRIES.map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
          {errors.country && <p className="text-xs text-signal-red">{errors.country.message}</p>}
        </div>

        <div className="flex flex-col gap-1.5">
          <Label htmlFor="platform">Platform</Label>
          <select
            id="platform"
            {...register("platform")}
            className="h-11 rounded-xl border border-slate-200 bg-slate-100 px-3 text-sm text-slate-900 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet/50"
          >
            {PLATFORMS.map((p) => (
              <option key={p} value={p}>{p}</option>
            ))}
          </select>
        </div>
      </div>

      <div className="flex flex-col gap-1.5">
        <Label>Favorite games</Label>
        <Controller
          name="favoriteGames"
          control={control}
          render={({ field }) => (
            <ChipMultiSelect value={field.value} onChange={field.onChange} />
          )}
        />
        <p className="text-xs text-steel/40">{favoriteGames?.length ?? 0}/8 selected</p>
        {errors.favoriteGames && <p className="text-xs text-signal-red">{errors.favoriteGames.message}</p>}
      </div>

      <div className="flex flex-col gap-1.5">
        <Label htmlFor="bio">Bio</Label>
        <Textarea id="bio" placeholder="Tell the squad who you are" {...register("bio")} />
        {errors.bio && <p className="text-xs text-signal-red">{errors.bio.message}</p>}
      </div>

      {submitError && <p className="text-sm text-signal-red">{submitError}</p>}

      <Button type="submit" size="lg" disabled={isSubmitting}>
        {checkingUsername ? "Checking username…" : isSubmitting ? "Saving…" : "Enter PlayConnect"}
      </Button>
    </form>
  );
}
