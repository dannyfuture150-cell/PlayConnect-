"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { signUpSchema, type SignUpInput } from "@/lib/validations/auth";
import { useAuthActions } from "@/hooks/useAuthActions";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { GoogleButton } from "@/components/auth/GoogleButton";

export function SignUpForm() {
  const router = useRouter();
  const { signUpWithEmail, loginWithGoogle, isLoading, error } = useAuthActions();
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<SignUpInput>({ resolver: zodResolver(signUpSchema) });

  async function onSubmit(data: SignUpInput) {
    await signUpWithEmail(data.email, data.password);
    router.push("/onboarding");
  }

  async function onGoogle() {
    await loginWithGoogle();
    router.push("/onboarding");
  }

  return (
    <div className="flex flex-col gap-5">
      <GoogleButton onClick={onGoogle} isLoading={isLoading} />

      <div className="flex items-center gap-3">
        <div className="h-px flex-1 bg-slate-100" />
        <span className="text-xs uppercase tracking-widest text-steel/40">or</span>
        <div className="h-px flex-1 bg-slate-100" />
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-4">
        <div className="flex flex-col gap-1.5">
          <Label htmlFor="email">Email</Label>
          <Input id="email" type="email" placeholder="you@example.com" {...register("email")} />
          {errors.email && <p className="text-xs text-signal-red">{errors.email.message}</p>}
        </div>

        <div className="flex flex-col gap-1.5">
          <Label htmlFor="password">Password</Label>
          <Input id="password" type="password" placeholder="At least 8 characters" {...register("password")} />
          {errors.password && <p className="text-xs text-signal-red">{errors.password.message}</p>}
        </div>

        <div className="flex flex-col gap-1.5">
          <Label htmlFor="confirmPassword">Confirm password</Label>
          <Input id="confirmPassword" type="password" placeholder="••••••••" {...register("confirmPassword")} />
          {errors.confirmPassword && <p className="text-xs text-signal-red">{errors.confirmPassword.message}</p>}
        </div>

        {error && <p className="text-sm text-signal-red">{error}</p>}

        <Button type="submit" size="lg" disabled={isLoading} className="mt-1">
          {isLoading ? "Creating account…" : "Create account"}
        </Button>
      </form>

      <p className="text-center text-sm text-steel/50">
        Already playing?{" "}
        <Link href="/login" className="font-medium text-violet-glow hover:underline">
          Sign in
        </Link>
      </p>
    </div>
  );
}
