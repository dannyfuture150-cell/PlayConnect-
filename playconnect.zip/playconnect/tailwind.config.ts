import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        // Core brand tokens — simple white + blue palette
        void: "#FFFFFF",       // main app background
        steel: "#1E293B",      // primary/secondary text (slate-800), used at various opacities
        violet: {
          DEFAULT: "#2563EB",  // primary blue (blue-600)
          deep: "#1D4ED8",     // blue-700
          glow: "#3B82F6",     // blue-500, used for links/highlights
        },
        cyan: {
          DEFAULT: "#38BDF8",  // sky-400, secondary accent
          deep: "#0284C7",     // sky-600
        },
        signal: {
          green: "#16A34A",
          red: "#DC2626",
          blue: "#2563EB",
          purple: "#1E40AF",   // deep blue-800, used for the top skill tier
        },
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))",
        },
      },
      fontFamily: {
        display: ["var(--font-display)"],
        body: ["var(--font-body)"],
      },
      backgroundImage: {
        "brand-gradient": "linear-gradient(90deg, #1D4ED8 0%, #2563EB 45%, #38BDF8 100%)",
        "brand-radial": "radial-gradient(circle at 30% 20%, rgba(37,99,235,0.06), transparent 60%), radial-gradient(circle at 80% 60%, rgba(56,189,248,0.05), transparent 55%)",
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
      keyframes: {
        "fade-up": {
          "0%": { opacity: "0", transform: "translateY(8px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        "pulse-glow": {
          "0%, 100%": { opacity: "0.6" },
          "50%": { opacity: "1" },
        },
      },
      animation: {
        "fade-up": "fade-up 0.5s ease-out both",
        "pulse-glow": "pulse-glow 2.4s ease-in-out infinite",
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
};
export default config;
