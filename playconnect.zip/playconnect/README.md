# PlayConnect

**Connect. Compete. Conquer.** A social network built for gamers — feed, player profiles, communities, and tournaments.

This repo is a real, running Next.js + Firebase application. What's built below is fully functional against a live Firebase project (not placeholder UI) — you can sign up, complete onboarding, post to a feed, like/comment in real time, and edit a public profile today. The remaining features in the original brief (stories, DMs, communities, tournaments, admin dashboard, notifications, explore/search) are scaffolded in the schema and security rules but not yet built as UI — see **Roadmap** below for the recommended build order.

## Tech stack

- Next.js 14 (App Router) + TypeScript
- Tailwind CSS, hand-rolled shadcn-style UI primitives
- Firebase Authentication, Firestore, Storage
- TanStack Query (React Query) for data fetching/caching
- React Hook Form + Zod for forms and validation
- Deployed to Vercel

## What's working right now

- **Auth**: email/password sign-up & login, Google sign-in, forgot-password, protected routes via `AuthGuard`
- **Onboarding**: username (uniqueness-checked), display name, country, platform, favorite games, bio
- **Profiles**: public profile page at `/profile/[username]`, player card, edit-profile in Settings
- **Feed**: create post, infinite-scroll timeline (newest first), like/unlike, live comments
- **Firestore security rules** and **Storage rules** covering every collection in the schema, so the backend is safe even for the not-yet-built features
- **Composite indexes** (`firestore.indexes.json`) for the queries currently in use

## Project structure

```
src/
  app/
    (auth)/           login, signup, forgot-password, onboarding
    (main)/            feed, profile/[username], settings — wrapped in AuthGuard
    layout.tsx          fonts, providers, metadata
    page.tsx             public landing page
  components/
    auth/                auth forms + shell
    feed/                post composer, post card, comments, feed list
    profile/             player card, profile header, edit-profile form
    layout/              navbar, sidebar
    shared/               logo, chip multi-select, auth guard, loader
    ui/                    button, input, card, avatar, dialog, label, textarea
  hooks/                 useAuthActions, usePosts, useComments, useProfile
  lib/
    firebase/client.ts    Firebase SDK init
    validations/          Zod schemas
    countries.ts, utils.ts
  providers/              AuthProvider, QueryProvider
  types/index.ts          Firestore data model
firestore.rules
firestore.indexes.json
storage.rules
```

## Firestore data model

| Collection | Shape | Notes |
|---|---|---|
| `users/{uid}` | `UserProfile` | Public profile doc; `onboardingComplete` gates access to `/feed` etc. |
| `usernames/{username}` | `{ uid }` | Reservation doc enforcing unique usernames without scanning `users`. |
| `posts/{postId}` | `Post` | Denormalizes author info (`author`) so the feed never needs a join. |
| `posts/{postId}/likes/{uid}` | `Like` | One doc per liker; existence = liked. |
| `posts/{postId}/comments/{commentId}` | `Comment` | Ordered by `createdAt` ascending. |
| `stories/{storyId}` | `Story` | Has `expiresAt`; pair with a scheduled Cloud Function or client-side filter to hide expired stories. |
| `followers/{uid}/list/{followerId}` | `FollowEdge` | `uid` is who's followed, `followerId` is who's following. |
| `threads/{threadId}/messages/{messageId}` | — | `threadId` should encode both UIDs (e.g. `uidA_uidB`, sorted) so rules can check membership. |
| `communities/{communityId}` | `Community` | Moderator list controls write access. |
| `tournaments/{tournamentId}` | `Tournament` | `participantIds` array; rules allow join-only updates. |
| `notifications/{uid}/items/{id}` | `AppNotification` | Per-user subcollection; only the owner can read/mark-read. |
| `reports/{reportId}` | `Report` | Write-only for reporters, read/resolve for admins. |
| `badges/{badgeId}` | `Badge` | Admin-managed catalog referenced by `users.badges: string[]`. |

`isAdmin` is a boolean on the `users` doc; set it manually in the Firebase console (or a Cloud Function) for staff accounts — there's no self-serve way to become an admin, by design.

## Setup

1. **Create a Firebase project** at console.firebase.google.com.
2. Enable **Authentication** → Email/Password and Google providers.
3. Create a **Firestore** database (production mode, pick a region).
4. Enable **Storage**.
5. In Project Settings → General, create a Web App and copy the config values into `.env.local` (copy `.env.local.example` first).
6. Install dependencies and run locally:
   ```bash
   npm install
   npm run dev
   ```
7. Deploy security rules and indexes with the Firebase CLI:
   ```bash
   npm install -g firebase-tools
   firebase login
   firebase init firestore storage   # point at this repo, keep existing rules files
   firebase deploy --only firestore:rules,firestore:indexes,storage:rules
   ```

## Deploying to Vercel

1. Push this repo to GitHub.
2. Import it in Vercel → New Project.
3. Add the same environment variables from `.env.local` in Vercel's Project Settings → Environment Variables.
4. Deploy. Next.js App Router works out of the box on Vercel with no extra config.

## Roadmap (in the order I'd build them)

1. **Media uploads** — wire the "Media" button in `CreatePostForm` to Firebase Storage (`avatars/`, `posts/{uid}/{postId}/` paths are already defined in `storage.rules`).
2. **Notifications** — write to `notifications/{uid}/items` whenever a like/comment/follow happens; build a bell dropdown off the existing Navbar.
3. **Communities** — list/detail pages over the `communities` collection; the rules and type are ready.
4. **Tournaments** — bracket UI is the heaviest lift here; start with create/join/list before brackets.
5. **Messaging** — real-time chat over `threads/{threadId}/messages`; add typing indicators via a `typing/{uid}` doc with a short TTL.
6. **Stories** — 24h media with a `viewers` array; filter expired stories client-side or with a scheduled Cloud Function cleanup.
7. **Explore/Search** — needs either Firestore's limited query support (prefix search on `username`) or a search service like Algolia/Typesense for full-text search across users, games, and communities.
8. **Admin dashboard** — a `/admin` route gated on `profile.isAdmin`, surfacing `reports` and moderation actions.

Each of these slots into the existing schema, rules, and component patterns without restructuring what's already built.
